-- MySQL dump 10.15  Distrib 10.0.31-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: findandg_caventa
-- ------------------------------------------------------
-- Server version	10.0.31-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `configuration`
--

DROP TABLE IF EXISTS `configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration` (
  `system_status` tinyint(4) NOT NULL,
  `version_code` int(11) NOT NULL,
  `version_name` double NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration`
--

LOCK TABLES `configuration` WRITE;
/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
INSERT INTO `configuration` (`system_status`, `version_code`, `version_name`, `id`) VALUES (1,1,1.11,1);
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `investments`
--

DROP TABLE IF EXISTS `investments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `investments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertion_date_time` datetime NOT NULL,
  `description` varchar(250) NOT NULL,
  `amount` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investments`
--

LOCK TABLES `investments` WRITE;
/*!40000 ALTER TABLE `investments` DISABLE KEYS */;
/*!40000 ALTER TABLE `investments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_installments`
--

DROP TABLE IF EXISTS `loan_installments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_installments` (
  `loan_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertion_date_time` datetime NOT NULL,
  `receipt_number` varchar(50) NOT NULL,
  `payed_amount` double NOT NULL,
  `principle` double NOT NULL,
  `intrest` double NOT NULL,
  `remarks` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_installments`
--

LOCK TABLES `loan_installments` WRITE;
/*!40000 ALTER TABLE `loan_installments` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_installments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loans`
--

DROP TABLE IF EXISTS `loans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertion_date_time` datetime NOT NULL,
  `description` varchar(250) NOT NULL,
  `loan_amount` double NOT NULL,
  `installment_amount` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loans`
--

LOCK TABLES `loans` WRITE;
/*!40000 ALTER TABLE `loans` DISABLE KEYS */;
/*!40000 ALTER TABLE `loans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `other_expenses`
--

DROP TABLE IF EXISTS `other_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `other_expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertion_date_time` datetime NOT NULL,
  `description` varchar(250) NOT NULL,
  `amount` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `other_expenses`
--

LOCK TABLES `other_expenses` WRITE;
/*!40000 ALTER TABLE `other_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `other_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `other_sales`
--

DROP TABLE IF EXISTS `other_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `other_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertion_date_time` datetime NOT NULL,
  `description` varchar(250) NOT NULL,
  `amount` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `other_sales`
--

LOCK TABLES `other_sales` WRITE;
/*!40000 ALTER TABLE `other_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `other_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_clear`
--

DROP TABLE IF EXISTS `payment_clear`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_clear` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clear_date_time` datetime NOT NULL DEFAULT '2017-08-01 18:00:00',
  `sales_person_id` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_clear`
--

LOCK TABLES `payment_clear` WRITE;
/*!40000 ALTER TABLE `payment_clear` DISABLE KEYS */;
INSERT INTO `payment_clear` (`id`, `clear_date_time`, `sales_person_id`) VALUES (68,'2017-08-01 18:00:00',6),(67,'2017-08-01 18:00:00',5),(66,'2017-08-01 18:00:00',4),(65,'2017-08-01 18:00:00',2);
/*!40000 ALTER TABLE `payment_clear` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_persons`
--

DROP TABLE IF EXISTS `sales_persons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_persons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_persons`
--

LOCK TABLES `sales_persons` WRITE;
/*!40000 ALTER TABLE `sales_persons` DISABLE KEYS */;
INSERT INTO `sales_persons` (`id`, `name`) VALUES (1,'Caventa'),(2,'Ameer'),(4,'Ansheer'),(5,'Anoop'),(6,'Lijith');
/*!40000 ALTER TABLE `sales_persons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `password`) VALUES (1,'admin','caventa');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_advances`
--

DROP TABLE IF EXISTS `work_advances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_advances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `work_id` int(11) NOT NULL,
  `insertion_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_advances`
--

LOCK TABLES `work_advances` WRITE;
/*!40000 ALTER TABLE `work_advances` DISABLE KEYS */;
INSERT INTO `work_advances` (`id`, `description`, `amount`, `work_id`, `insertion_date_time`) VALUES (7,'',40000,5,'2017-12-23 11:39:34'),(8,'',8000,6,'2017-12-23 19:42:00'),(9,'',10000,8,'2018-01-01 13:50:32'),(15,'',1800,9,'2018-01-02 19:52:30'),(35,'',55000,7,'2018-02-05 17:11:30'),(34,'8-01-18',70000,7,'2018-02-05 17:11:30'),(26,'',50000,11,'2018-01-30 17:34:52'),(36,'',40000,12,'2018-02-05 17:17:57'),(22,'',800,13,'2018-01-18 18:44:44'),(37,'',20000,10,'2018-02-05 17:27:40');
/*!40000 ALTER TABLE `work_advances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_expenses`
--

DROP TABLE IF EXISTS `work_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `work_id` int(11) NOT NULL,
  `insertion_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_expenses`
--

LOCK TABLES `work_expenses` WRITE;
/*!40000 ALTER TABLE `work_expenses` DISABLE KEYS */;
INSERT INTO `work_expenses` (`id`, `description`, `amount`, `work_id`, `insertion_date_time`) VALUES (6,'EXPOSING \nVAHID,SAFAD,SHIBIN, LIJITH,RAHUL AND FUE',36000,5,'2017-12-23 11:39:34'),(7,'Lijith expossing',5000,6,'2017-12-23 19:42:00'),(8,'Ansheer editing',500,6,'2017-12-23 19:42:00'),(9,'Ratheesh',6000,8,'2018-01-01 13:50:32'),(107,'Edit safad',4000,12,'2018-02-05 17:17:57'),(100,'Asif',8000,7,'2018-02-05 17:11:30'),(101,'shebi video',10000,7,'2018-02-05 17:11:30'),(99,'basil',10000,7,'2018-02-05 17:11:30'),(21,'',1100,9,'2018-01-02 19:52:30'),(98,'Faisal',10000,7,'2018-02-05 17:11:30'),(97,'Gazal',12500,7,'2018-02-05 17:11:30'),(63,'Vahid video',10000,11,'2018-01-30 17:34:52'),(62,'Lijith',6500,11,'2018-01-30 17:34:52'),(61,'Amir kokkodi',15000,11,'2018-01-30 17:34:52'),(60,'Faisal chettipadi',10000,11,'2018-01-30 17:34:52'),(59,'Gazal',16000,11,'2018-01-30 17:34:52'),(106,'Lijith',6500,12,'2018-02-05 17:17:57'),(105,'Bazil photo',7000,12,'2018-02-05 17:17:57'),(104,'Amir kokkodi',8000,12,'2018-02-05 17:17:57'),(46,'edit ansheer',600,13,'2018-01-18 18:44:44'),(96,'Ameer',10000,7,'2018-02-05 17:11:30'),(103,'Vahid video',10000,12,'2018-02-05 17:17:57'),(64,'Safad video',7500,11,'2018-01-30 17:34:52'),(95,'Stage purple',50000,7,'2018-02-05 17:11:30'),(102,'Safad',7500,12,'2018-02-05 17:17:57'),(94,'Sounds',9000,7,'2018-02-05 17:11:30'),(108,'Still Lijith',8000,10,'2018-02-05 17:27:40'),(109,'Video Safad',8000,10,'2018-02-05 17:27:40'),(110,'Travel & Food',1800,10,'2018-02-05 17:27:40');
/*!40000 ALTER TABLE `work_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_profits`
--

DROP TABLE IF EXISTS `work_profits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `work_profits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `work_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `sales_person_id` int(11) NOT NULL,
  `insertion_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_profits`
--

LOCK TABLES `work_profits` WRITE;
/*!40000 ALTER TABLE `work_profits` DISABLE KEYS */;
INSERT INTO `work_profits` (`id`, `work_id`, `amount`, `sales_person_id`, `insertion_date_time`) VALUES (6,6,1500,5,'2017-12-23 19:42:51'),(7,6,1000,1,'2017-12-23 19:42:51'),(8,13,200,1,'2018-01-18 18:45:03');
/*!40000 ALTER TABLE `work_profits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `works`
--

DROP TABLE IF EXISTS `works`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `works` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `work_date` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `insertion_date_time` datetime NOT NULL,
  `sales_person_id` int(11) NOT NULL,
  `deletion_date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `works`
--

LOCK TABLES `works` WRITE;
/*!40000 ALTER TABLE `works` DISABLE KEYS */;
INSERT INTO `works` (`id`, `name`, `address`, `work_date`, `status`, `insertion_date_time`, `sales_person_id`, `deletion_date_time`) VALUES (5,'MIDHUN SHIKHA','KOZHIKODE','2017-11-05',0,'2017-12-23 11:39:34',6,NULL);
/*!40000 ALTER TABLE `works` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'findandg_caventa'
--

--
-- Dumping routines for database 'findandg_caventa'
--
/*!50003 DROP FUNCTION IF EXISTS `get_work_profit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`findandg`@`localhost` FUNCTION `get_work_profit`(`given_work_id` INT) RETURNS float
BEGIN
  DECLARE advances FLOAT;
  DECLARE expenses FLOAT;
  
  SELECT SUM(amount) INTO advances FROM work_advances WHERE work_id=given_work_id;
  SELECT SUM(amount) INTO expenses FROM work_expenses WHERE work_id=given_work_id;
  
  RETURN (advances-expenses);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_work_overviews` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`findandg`@`localhost` PROCEDURE `get_work_overviews`(IN `given_sales_person_id` INT)
BEGIN
	
	DECLARE var_id INT;
	
	DECLARE done INT DEFAULT FALSE;
	DECLARE cur1 CURSOR FOR SELECT `works`.`id` FROM `works` WHERE `sales_person_id` = given_sales_person_id;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	
	DROP TABLE IF EXISTS `work_overviews`;
	CREATE TEMPORARY TABLE IF NOT EXISTS `work_overviews` (
		`name` varchar(50) NOT NULL,
		`address` varchar(250) NOT NULL,
		`work_date` date NOT NULL,
		`total_advance` double DEFAULT NULL,
		`total_expense` double DEFAULT NULL
	) ENGINE=MyISAM DEFAULT CHARSET=latin1;

	OPEN cur1;
	
	read_loop: LOOP
		
		FETCH cur1 INTO var_id;
		
		IF done THEN
		  LEAVE read_loop;
		END IF;
		
		INSERT INTO `work_overviews`(`name`, `address`, `work_date`, `total_advance`, `total_expense`)
		SELECT `work_overview`.`name`,`work_overview`.`address`,`work_overview`.`work_date`,`work_overview`.`total_advance`,`work_overview`.`total_expense` FROM
			( SELECT * FROM 
				( SELECT `name`, `address`, `work_date`,`works`.`id` FROM `works` 
					WHERE `id` =var_id ) AS `works`
			JOIN
				( SELECT * FROM 
					( SELECT SUM( `work_advances`.`amount` ) AS total_advance,`work_advances`.`work_id` FROM `work_advances`
						WHERE  `work_advances`.`work_id`=var_id ) as `work_advances_sum`

				JOIN 
					( SELECT SUM( `work_expenses`.`amount` ) AS total_expense,`work_expenses`.`work_id` AS `expense_work_id` FROM `work_expenses` 
						WHERE `work_expenses`.`work_id`=var_id ) as `work_expenses_sum` ) 
			AS `work_advances_expenses_sum` ) 
		AS `work_overview`;
		
	END LOOP;
	
	CLOSE cur1;
	
	SELECT `name`, `address`, `work_date`, `total_advance`, `total_expense` FROM `work_overviews`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-13 18:30:56
